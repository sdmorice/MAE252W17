%drawang.m - plots a ray based on starting posn, theta, and magnitude
%  written by: Shawn Lankton
%  for: ECE8843 (sort-of) fun (mostly)
%
%  This draws rays coming from the center of the robot.  I use these to
%  help visulize rangefinders.  This is called from drawbot.
%
%  Inputs:
%    posn - [yposn, mag]
%    mag - length of the line (pixels)
%
%  Outputs:
%    none
%

function drawang(posn, mag)

% do some polar to cartesian math
y = [posn(1), posn(1)+ mag*sin(posn(3))];
x = [posn(2), posn(2)+ mag*cos(posn(3))];

%plot the line
plot(y,x,'r');
