function distsensorrobot
% This demo shows how to use the function distsensormodel which performs
% the environment modeling algorithm.
% You can draw some lines with your mouse to define walls. After you finish
% drawing, click stop and click your mouse to locate the robot. Then use
% keyboard to move the robot. The measurement data of ultrasonic distance
% sensors is simulated by calling function sonomeasure.
%
% Parameters: 
%  N, number of sensors;
%  r, radius of robot;
%
% Jan/14/2015, hanligong(AT)gmail(DOT)com

N = 24;
r = 0.20;
rstep = 0.05;
segments = [];
%% handles
% figure
h_f = figure('name','Ultrasonic Sensor Robot','menubar','none','numbertitle','off',...
    'color',[1 1 1],'position',[250,100,800,600],'keypressfcn','');
h_a = axes('parent',h_f,'xlim',[0 8],'ylim',[0 6],'position',[0,0,1,1],...
    'box','on','dataaspectratio',[1 1 1],'xtick',[],'ytick',[],'xcolor',[1 1 1],'ycolor',[1 1 1]);
h_msg = uicontrol(h_f,'style','text','position',[65,5,660,52]);
h_msg_air = uicontrol(h_f,'style','text','position',[80,220,640,160],...
    'backgroundcolor',[1 1 1],'string','Draw some lines in this window to defines walls...',...
    'fontsize',22,'HorizontalAlignment','center','fontweight','bold',...
    'foregroundcolor',[.1 .25 1]);
uicontrol(h_f,'style','pushbutton','position',[800-65 5 60 25],...
    'fontsize',11,'callback',@clear_lines,'string','Clear');
uicontrol(h_f,'style','pushbutton','position',[800-65 32 60 25],...
    'fontsize',11,'callback',@stop_input,'string','Stop');
uicontrol(h_f,'style','pushbutton','position',[800-65 570 60 25],...
    'fontsize',11,'callback',@start_demo,'string','Demo');
% lines
h_l_o = line(NaN,NaN,'parent',h_a,'color',[0.75 0 0],'linestyle','-',...
    'linewidth',2.5,'marker','o','markersize',6,'MarkerEdgeColor',[0 0 0.75]);
h_l_n = line(NaN,NaN,'parent',h_a,'color',[1 0.5 0],'linestyle','-',...
    'linewidth',3);
h_l_measure = zeros(1,N);
h_l_rbt = line('parent',h_a,'xdata',nan,'ydata',nan,'marker','o','color',[1 0 0]);
h_l_robot = line(nan,nan,'parent',h_a,'color',[0.75 0 0],'linewidth',2);
for ik = 1:N
    h_l_measure(ik) = line(NaN,NaN,'parent',h_a,'color',[0.1 0 1],'linestyle','--','linewidth',2);
end
h_l_model = zeros(1,N);
for ik = 1:N
    h_l_model(ik) = line(NaN,NaN,'parent',h_a,'color',[0 0 0],'linestyle','-','linewidth',2.5);
end

a = 2*pi/N;
theta = a/2:a:2*pi;
ang = a*ones(N,1);
cx = cell(1,N);
cy = cell(1,N);
for ik = 1:N
    cx{ik} = cos((ik-1:.1:ik)*a);
    cy{ik} = sin((ik-1:.1:ik)*a);
end
cxr = cos((0:.05:2)*pi);
cyr = sin((0:.05:2)*pi);

n_seg = 0;
ix_new = 0;
x_new = [];
y_new = [];
x_old = [];
y_old = [];

rx = nan;
ry = nan;

set(h_f,'windowbuttonupfcn',@stopdragfcn)
set(h_a,'buttondownfcn',@startdragfcn)
% display instruction
set(h_msg,'string',['Draw lines with your mouse to define walls... '...
    'If you want to redraw the lines, click CLEAR. '...
    'Then click STOP and locate your robot.'],...
    'fontsize',12,'horizontal','left');
pause(2.5)
set(h_msg_air,'string','')
pause(0.75)
set(h_msg_air,'string','After finishing, click STOP and locate the position of your robot.');
pause(2.5)
set(h_msg_air,'visible','off');
firsttime = true;

    function startdragfcn(varargin)
        set(h_f,'windowbuttonmotionfcn',@draggingfcn);
        ix_new = 0;
        x_new = [];
        y_new = [];
    end

    function stopdragfcn(varargin)
        set(h_f,'windowbuttonmotionfcn','');
        % Call RDP Fcn
        if ~isempty(x_new)
            ptList = DouglasPeucker([x_new,y_new],0.05,false);
            x_old = [x_old; nan; ptList(:,1)];
            y_old = [y_old; nan; ptList(:,2)];
            set(h_l_o,'xdata',x_old,'ydata',y_old);
            set(h_l_n,'xdata',nan,'ydata',nan);
        end
    end

    function draggingfcn(varargin)
        ix_new = ix_new+1;
        pt = get(h_a,'currentpoint');
        x_new(ix_new,1) = pt(1,1);
        y_new(ix_new,1) = pt(1,2);
        set(h_l_n,'xdata',x_new,'ydata',y_new)
    end

    function clear_lines(varargin)
        ix_new = 0;
        x_new = [];
        y_new = [];
        x_old = [];
        y_old = [];
        set(h_l_o,'xdata',nan,'ydata',nan);
        set(h_l_n,'xdata',nan,'ydata',nan);
        set(h_f,'keypressfcn','')
    end

    function stop_input(varargin)
        set(h_l_o,'linestyle','--','linewidth',3,'marker','none')
        % input robot position
        set(h_msg,'string','Now locate your robot...')
        if firsttime
            set(h_msg_air,'visible','on');
            set(h_msg_air,'string',['Click mouse to locate the robot... '...
                'Then use your keyboard to move the robot.']);
            pause(2.5)
            set(h_msg_air,'visible','off');
            firsttime = false;
        end
        [rx,ry] = ginput(1);
        set(h_l_rbt,'xdata',rx,'ydata',ry);
        % generate segments
        generate_segments;
    end

    function generate_segments
        n_seg = 0;
        segments = zeros(length(x_old),4);
        for fk = 1:length(x_old)-1
            if ~isnan(x_old(fk)) && ~isnan(x_old(fk+1))
                n_seg = n_seg+1;
                segments(n_seg,:) = [x_old(fk),y_old(fk),x_old(fk+1),y_old(fk+1)];
            end
        end
        segments(n_seg+1:end,:) = [];
        start_work;
    end

    function start_work
        set(h_f,'keypressfcn',@robot_move_fcn)
    end

    function start_demo(varargin)
        x_old = [1,2.5,7,7,5.5,1,1]';
        y_old = [2.5,1,1,3.5,5,5,2.5]';
        rx = 4;
        ry = 3;
        generate_segments;
        set(h_l_o,'linestyle','--','linewidth',3,'marker','none',...
            'xdata',x_old,'ydata',y_old)
        set(h_l_robot,'xdata',r*cxr+rx,'ydata',r*cyr+ry)
        set(h_l_rbt,'xdata',rx,'ydata',ry);
    end

    function robot_move_fcn( ~,evt)
        rxo = rx;
        ryo = ry;
        switch evt.Key
            case {'w','uparrow'}
                ry = ry+rstep;
            case {'s','downarrow'}
                ry = ry-rstep;
            case {'a','leftarrow'}
                rx = rx-rstep;
            case {'d','rightarrow'}
                rx = rx+rstep;
        end
        if check_overlap([rx,ry],2*r)
            set(h_msg,'string','Approaching wall...');
        else
            set(h_msg,'string','Sensing and modeling the environment...');
        end
        [istouch,~] = check_overlap([rx,ry],r);
        if istouch
            set(h_msg,'string','Robot has touched wall... Move back.');
            rx = rxo;
            ry = ryo;
        end
        if ~istouch
            %reprobe
            rs = sonomeasure(segments,[rx,ry],false,N);
            [mdl_pt,~] = distsensormodel(rs,theta,ang);
            set(h_l_model,'xdata',NaN,'ydata',NaN)
            set(h_l_robot,'xdata',r*cxr+rx,'ydata',r*cyr+ry)
            set(h_l_rbt,'xdata',rx,'ydata',ry);
            for fk = 1:N
                %measurement data
                set(h_l_measure(fk),'xdata',rs(fk)*cx{fk}+rx,'ydata',rs(fk)*cy{fk}+ry)
                %modeling lines
                set(h_l_model(fk),'xdata',mdl_pt(fk,1:3)+rx,'ydata',mdl_pt(fk,4:6)+ry)
            end
        end
    end

    function [istouchall,istouch] = check_overlap(rpos,r)
        istouch = true(1,n_seg);
        istouchall = false;
        for k = 1:n_seg
            if segments(k,2) ~= segments(k,4)
                A = 1;
                B = -(segments(k,1)-segments(k,3))/(segments(k,2)-segments(k,4));
                C = (segments(k,1)-segments(k,3))/(segments(k,2)-segments(k,4))*...
                    segments(k,2)-segments(k,1);
                d = abs((A*rpos(1)+B*rpos(2)+C)/sqrt(A^2+B^2));
                inarea = (rpos(2)-segments(k,2)+(segments(k,1)-segments(k,3))/...
                    (segments(k,2)-segments(k,4))*(rpos(1)-segments(k,1)))*...
                    (rpos(2)-segments(k,4)+(segments(k,1)-segments(k,3))/...
                    (segments(k,2)-segments(k,4))*(rpos(1)-segments(k,3))) < 0;
            else
                d = abs(rpos(2)-segments(k,2));
                inarea = (rpos(1)-segments(k,1))*(rpos(1)-segments(k,3)) < 0;
            end
            if (inarea && d >= r) || (~inarea && (sqrt((rpos(1)-segments(k,1))^2+...
                    (rpos(2)-segments(k,2))^2) >= r && sqrt((rpos(1)-...
                    segments(k,3))^2+(rpos(2)-segments(k,4))^2) >= r))
                istouch(k) = false;
            else
                istouchall = true;
            end
        end
    end

end
