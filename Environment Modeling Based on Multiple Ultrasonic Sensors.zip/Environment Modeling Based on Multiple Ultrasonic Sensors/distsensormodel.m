function [mdl_pt, mdl_type] = distsensormodel(ds,theta,a)
%DISTSENSORMODEL   [mdl_pt, mdl_type] = distsensormodel(ds,theta,a)
%   Precise environmental modeling based on multiple distance sensors(esp.
%   ultrasonic sensors).
%   The input arguement 'ds' is the measured data(distance).
%   'theta' is the angles between x axis and the central line of each fan
%   sector.
%   'a' is the opening angles of fans.
%   'mdl_pt' is a matrix contains modeled line segments(coordinates of
%   points) for each sensor.
%   'mdl_type' is the model type of each fan.
%
%   phymhan
%   $ 18-Aug-2013 18:46:58 $

%Format:
%   ds      : [d1;d2;...]
%   theta   : [th1,th2;...]
%   a       : [a1;a2;...]
%   mdl_pt  : [x11 x12 x13, y11 y12 y13;...]
%   mdl_type: [type1;type2;...]

%Model Type:
%   faultage2        : 01
%   faultage1        : 02
%   wall             : 03
%   outer corner (a) : 04
%   outer corner (b1): 05
%   outer corner (b2): 06
%   inner corner     : 07
%   undefined        : 08

%Notation:
%   i>|<j;     %+|-1
%   i>>|<<j;   %+|-2
%   i>>>|<<<j; %+|-3

%Distance relation:
% dsR: [ii->ij, ii->ik, ij->jl, ik->im]

%In this version, rs = ds.

N = length(ds);
d_th = 0.6; %threshold distance for faultage
d_inf = inf; %distance regarded as infinity
%r_add = 1.5; %dynamic condition
mdl_done = false(N,1);
mdl_pt = zeros(N,6);
mdl_type = 3*ones(N,1); %initial: wall
pto = [0 0];
offset = -0.01;
for ii = 1:N
    if mdl_done(ii)
        continue
    end
    if ds(ii) > d_inf
        mdl_pt(ii,:) = [ ...
            NaN NaN NaN, ...
            NaN NaN NaN];
        mdl_done(ii) = true;
        %disp('out')
        continue
    end
    %Dynamic threshold
    d_mean = mean(ds);
    d_th = d_mean*0.40+ds(ii)*0.20; %#
    r_add = d_mean*0.30+ds(ii)*0.30; %#
%     d_th = d_mean*0.20+ds(ii)*0.10; %#
%     r_add = d_mean*0.15+ds(ii)*0.15; %#
    %neighboring sensors
    ij = nextIdx(ii,N, 1);
    ik = nextIdx(ii,N,-1);
    il = nextIdx(ii,N, 2);
    im = nextIdx(ii,N,-2);
    %Compute dsR
    dsR = CompdsR;
    %Modeling
    if (abs(dsR(1))==3) || (abs(dsR(2))==3)
        %faultage:
        if abs(dsR(1))==3 && abs(dsR(2))==3
            %faultage2:
            mdl_type(ii) = 1;
            %ii:
            mdl_pt(ii,:) = ds(ii).*[ ...
                cos(theta(ii)-a(ii)/4) cos(theta(ii)+a(ii)/4) NaN, ...
                sin(theta(ii)-a(ii)/4) sin(theta(ii)+a(ii)/4) NaN];
            %ij:
            if dsR(3) == 1
                D1 = ds(il)/cos(a(il)/2);
                D2 = ds(il)/cos(a(il)/2+a(ij));
                mdl_pt(ij,:) = [ ...
                    D1*cos(theta(il)-a(il)/2) D2*cos(theta(il)-a(il)/2-a(ij)) NaN, ...
                    D1*sin(theta(il)-a(il)/2) D2*sin(theta(il)-a(il)/2-a(ij)) NaN];
            elseif dsR(3) == -2
                D1 = ds(il);
                D2 = ds(ij);
                mdl_pt(ij,:) = [ ...
                    D1*cos(theta(ij)+a(ij)/2) D2*cos(theta(ij)-a(ij)/2) NaN, ...
                    D1*sin(theta(ij)+a(ij)/2) D2*sin(theta(ij)-a(ij)/2) NaN];
            else
                %dsR(3)==2 || dsR(3)==-1 OR undefined situation
                D1 = ds(ij)/cos(a(ij)/2);
                D2 = D1;
                mdl_pt(ij,:) = [ ...
                    D1*cos(theta(ij)+a(ij)/2) D2*cos(theta(ij)-a(ij)/2) NaN, ...
                    D1*sin(theta(ij)+a(ij)/2) D2*sin(theta(ij)-a(ij)/2) NaN];
            end
            %ik:
            if dsR(4) == 1
                D1 = ds(im)/cos(a(im)/2);
                D2 = ds(im)/cos(a(im)/2+a(ik));
                mdl_pt(ik,:) = [ ...
                    D1*cos(theta(im)+a(im)/2) D2*cos(theta(im)+a(im)/2+a(ik)) NaN, ...
                    D1*sin(theta(im)+a(im)/2) D2*sin(theta(im)+a(im)/2+a(ik)) NaN];
            elseif dsR(4) == -2
                D1 = ds(im);
                D2 = ds(ik);
                mdl_pt(ik,:) = [ ...
                    D1*cos(theta(ik)-a(ik)/2) D2*cos(theta(ik)+a(ik)/2) NaN, ...
                    D1*sin(theta(ik)-a(ik)/2) D2*sin(theta(ik)+a(ik)/2) NaN];
            else
                %dsR(4)==2 || dsR(4)==-1 OR undefined situation
                D1 = ds(ik)/cos(a(ik)/2);
                D2 = D1;
                mdl_pt(ik,:) = [ ...
                    D1*cos(theta(ik)-a(ik)/2) D2*cos(theta(ik)+a(ik)/2) NaN, ...
                    D1*sin(theta(ik)-a(ik)/2) D2*sin(theta(ik)+a(ik)/2) NaN];
            end
            mdl_done([ij ik]) = true; %!!
        else
            %faultage1:
            mdl_type(ii) = 2;
            if abs(dsR(1)) == 3
                %ii:
                if dsR(2) == 1
                    D1 = ds(ik)/cos(a(ik)/2);
                    D2 = ds(ik)/cos(a(ik)/2+a(ii));
                    mdl_pt(ii,:) = [ ...
                        D1*cos(theta(ik)+a(ik)/2) D2*cos(theta(ik)+a(ik)/2+a(ii)) NaN, ...
                        D1*sin(theta(ik)+a(ik)/2) D2*sin(theta(ik)+a(ik)/2+a(ii)) NaN];
                elseif dsR(2) == -2
                    D1 = ds(ik);
                    D2 = ds(ii);
                    mdl_pt(ii,:) = [ ...
                        D1*cos(theta(ii)-a(ii)/2) D2*cos(theta(ii)+a(ii)/2) NaN, ...
                        D1*sin(theta(ii)-a(ii)/2) D2*sin(theta(ii)+a(ii)/2) NaN];
                else
                    %dsR(2)==2 || dsR(2)==-1
                    D1 = ds(ii)/cos(a(ii)/2);
                    D2 = D1;
                    mdl_pt(ii,:) = [ ...
                        D1*cos(theta(ii)-a(ii)/2) D2*cos(theta(ii)+a(ii)/2) NaN, ...
                        D1*sin(theta(ii)-a(ii)/2) D2*sin(theta(ii)+a(ii)/2) NaN];
                end
                %ij:
                if dsR(3) == 1
                    D1 = ds(il)/cos(a(il)/2);
                    D2 = ds(il)/cos(a(il)/2+a(ij));
                    mdl_pt(ij,:) = [ ...
                        D1*cos(theta(il)-a(il)/2) D2*cos(theta(il)-a(il)/2-a(ij)) NaN, ...
                        D1*sin(theta(il)-a(il)/2) D2*sin(theta(il)-a(il)/2-a(ij)) NaN];
                elseif dsR(3) == -2
                    D1 = ds(il);
                    D2 = ds(ij);
                    mdl_pt(ij,:) = [ ...
                        D1*cos(theta(ij)+a(ij)/2) D2*cos(theta(ij)-a(ij)/2) NaN, ...
                        D1*sin(theta(ij)+a(ij)/2) D2*sin(theta(ij)-a(ij)/2) NaN];
                else
                    %dsR(3)==2 || dsR(3)==-1 OR undefined situation
                    D1 = ds(ij)/cos(a(ij)/2);
                    D2 = D1;
                    mdl_pt(ij,:) = [ ...
                        D1*cos(theta(ij)+a(ij)/2) D2*cos(theta(ij)-a(ij)/2) NaN, ...
                        D1*sin(theta(ij)+a(ij)/2) D2*sin(theta(ij)-a(ij)/2) NaN];
                end
                mdl_done(ij) = true; %!!
            else %dsR(2) == 3
                %ii:
                if dsR(1) == 1
                    D1 = ds(ij)/cos(a(ij)/2);
                    D2 = ds(ij)/cos(a(ij)/2+a(ii));
                    mdl_pt(ii,:) = [ ...
                        D1*cos(theta(ij)-a(ij)/2) D2*cos(theta(ij)-a(ik)/2-a(ii)) NaN, ...
                        D1*sin(theta(ij)-a(ik)/2) D2*sin(theta(ij)-a(ij)/2-a(ii)) NaN];
                elseif dsR(1) == -2
                    D1 = ds(ij);
                    D2 = ds(ii);
                    mdl_pt(ii,:) = [ ...
                        D1*cos(theta(ii)+a(ii)/2) D2*cos(theta(ii)-a(ii)/2) NaN, ...
                        D1*sin(theta(ii)+a(ii)/2) D2*sin(theta(ii)-a(ii)/2) NaN];
                else
                    %dsR(1)==2 || dsR(1)==-1
                    D1 = ds(ii)/cos(a(ii)/2);
                    D2 = D1;
                    mdl_pt(ii,:) = [ ...
                        D1*cos(theta(ii)+a(ii)/2) D2*cos(theta(ii)-a(ii)/2) NaN, ...
                        D1*sin(theta(ii)+a(ii)/2) D2*sin(theta(ii)-a(ii)/2) NaN];
                end
                %ik:
                if dsR(4) == 1
                    D1 = ds(im)/cos(a(im)/2);
                    D2 = ds(im)/cos(a(im)/2+a(ik));
                    mdl_pt(ik,:) = [ ...
                        D1*cos(theta(im)+a(im)/2) D2*cos(theta(im)+a(im)/2+a(ik)) NaN, ...
                        D1*sin(theta(im)+a(im)/2) D2*sin(theta(im)+a(im)/2+a(ik)) NaN];
                elseif dsR(4) == -2
                    D1 = ds(im);
                    D2 = ds(ik);
                    mdl_pt(ik,:) = [ ...
                        D1*cos(theta(ik)-a(ik)/2) D2*cos(theta(ik)+a(ik)/2) NaN, ...
                        D1*sin(theta(ik)-a(ik)/2) D2*sin(theta(ik)+a(ik)/2) NaN];
                else
                    %dsR(4)==2 || dsR(4)==-1 OR undefined situation
                    D1 = ds(ik)/cos(a(ik)/2);
                    D2 = D1;
                    mdl_pt(ik,:) = [ ...
                        D1*cos(theta(ik)-a(ik)/2) D2*cos(theta(ik)+a(ik)/2) NaN, ...
                        D1*sin(theta(ik)-a(ik)/2) D2*sin(theta(ik)+a(ik)/2) NaN];
                end
                mdl_done(ik) = true; %!!
            end
        end
    elseif ((dsR(2)==1 || dsR(2)==2) && dsR(1)==-2 && (dsR(3)==-2 || dsR(3)==-3 || dsR(3)==3)) || ...
            ((dsR(1)==1 || dsR(1)==2) && dsR(2)==-2 && (dsR(4)==-2 || dsR(4)==-3 || dsR(4)==3))
        %wall:
        mdl_type(ii) = 3; %#
        if dsR(2) < 0
            D1 = ds(ik);
            D2 = ds(ii);
            mdl_pt(ii,:) = [ ...
                D1*cos(theta(ii)-a(ii)/2) D2*cos(theta(ii)+a(ii)/2) NaN, ...
                D1*sin(theta(ii)-a(ii)/2) D2*sin(theta(ii)+a(ii)/2) NaN];
        else %dsR(1) < 0
            D1 = ds(ij);
            D2 = ds(ii);
            mdl_pt(ii,:) = [ ...
                D1*cos(theta(ii)+a(ii)/2) D2*cos(theta(ii)-a(ii)/2) NaN, ...
                D1*sin(theta(ii)+a(ii)/2) D2*sin(theta(ii)-a(ii)/2) NaN];
        end
    elseif (all(dsR([3 4 1])==[-1 2 -2]) && dsR(2)>0) || ...
            (all(dsR([4 3 2])==[-1 2 -2]) && dsR(1)>0)
        %outer corner (a):
        %e|il|a|ij|b|ii|d|ik|c|im|f
        %ptt: tmp point, pto: origin
        mdl_type(ii) = 4;
        if dsR(3) < 0
            %ij:
            D1 = ds(ij)/cos(a(ij));
            D2 = ds(ij)/cos(a(ij)/2);
            pta = D1*[cos(theta(ij)+a(ij)/2) sin(theta(ij)+a(ij)/2)];
            ptb = D2*[cos(theta(ij)-a(ij)/2) sin(theta(ij)-a(ij)/2)];
            %ik:
            D1 = ds(ik);
            D2 = ds(ii); %!!
            ptc = D1*[cos(theta(ik)-a(ik)/2) sin(theta(ik)-a(ik)/2)];
            ptd = D2*[cos(theta(ik)+a(ik)/2) sin(theta(ik)+a(ik)/2)];
            %ii:
            [x, y] = lineIntr(pta,ptb,ptc,ptd);
            pti = [x y];
            ang = vectAng(ptb-pti,ptd-pti);
            if ang > 0
                %outer corner (a):
                mdl_pt(ii,:) = [ ...
                    ptb(1) pti(1) ptd(1), ...
                    ptb(2) pti(2) ptd(2)];
                mdl_pt(ij,:) = [ ...
                    pta(1) ptb(1) NaN, ...
                    pta(2) ptb(2) NaN];
                mdl_pt(ik,:) = [ ...
                    ptc(1) ptd(1) NaN, ...
                    ptc(2) ptd(2) NaN];
                mdl_done([ij ik]) = true;
            else
                %undefined situation:
                mdl_type(ii) = 8;
                D1 = ds(ii)/cos(a(ii)/2);
                D2 = D1;
                mdl_pt(ii,:) = [ ...
                    D1*cos(theta(ii)+a(ii)/2) D2*cos(theta(ii)-a(ii)/2) NaN, ...
                    D1*sin(theta(ii)+a(ii)/2) D2*sin(theta(ii)-a(ii)/2) NaN];
            end
        else %dsR(4) < 0
            %ik:
            D1 = ds(ik)/cos(a(ik));
            D2 = ds(ik)/cos(a(ik)/2);
            ptc = D1*[cos(theta(ik)-a(ik)/2) sin(theta(ik)-a(ik)/2)];
            ptd = D2*[cos(theta(ik)+a(ik)/2) sin(theta(ik)+a(ik)/2)];
            %ij:
            D1 = ds(ij);
            D2 = ds(ii); %!!
            pta = D1*[cos(theta(ij)+a(ij)/2) sin(theta(ij)+a(ij)/2)];
            ptb = D2*[cos(theta(ij)-a(ij)/2) sin(theta(ij)-a(ij)/2)];
            %ii:
            [x, y] = lineIntr(pta,ptb,ptc,ptd);
            pti = [x y];
            ang = vectAng(ptb-pti,ptd-pti);
            if ang > 0
                %outer corner (a):
                mdl_pt(ii,:) = [ ...
                    ptb(1) pti(1) ptd(1), ...
                    ptb(2) pti(2) ptd(2)];
                mdl_pt(ij,:) = [ ...
                    pta(1) ptb(1) NaN, ...
                    pta(2) ptb(2) NaN];
                mdl_pt(ik,:) = [ ...
                    ptc(1) ptd(1) NaN, ...
                    ptc(2) ptd(2) NaN];
                mdl_done([ij ik]) = true;
            else
                %undefined situation:
                mdl_type(ii) = 8;
                D1 = ds(ii)/cos(a(ii)/2);
                D2 = D1;
                mdl_pt(ii,:) = [ ...
                    D1*cos(theta(ii)+a(ii)/2) D2*cos(theta(ii)-a(ii)/2) NaN, ...
                    D1*sin(theta(ii)+a(ii)/2) D2*sin(theta(ii)-a(ii)/2) NaN];
            end
        end
        mdl_done([ij ik]) = true;
    elseif (dsR(3)==1 || dsR(3)==2) && (dsR(4)==1 || dsR(4)==2) && ...
            (dsR(1)>0||dsR(2)>0)
        %outer corner (b):
        %e|il|a|ij|b|ii|d|ik|c|im|f
        %ptt: tmp point, pto: origin
        %ij:
        D1 = ds(ij);
        pte = ds(il)*[cos(theta(il)+a(il)/2) sin(theta(il)+a(il)/2)];
        pta = D1*[cos(theta(ij)+a(ij)/2) sin(theta(ij)+a(ij)/2)];
        %pto = [0 0];
        ptt = ds(ij)*[cos(theta(ij)-a(ij)/2) sin(theta(ij)-a(ij)/2)];
        [x, y] = lineIntr(pte,pta,pto,ptt);
        ptb = [x y];
        %ik:
        D1 = ds(ik);
        ptf = ds(im)*[cos(theta(im)-a(im)/2) sin(theta(im)-a(im)/2)];
        ptc = D1*[cos(theta(ik)-a(ik)/2) sin(theta(ik)-a(ik)/2)];
        %pto = [0 0];
        ptt = ds(ik)*[cos(theta(ik)+a(ik)/2) sin(theta(ik)+a(ik)/2)];
        [x, y] = lineIntr(ptf,ptc,pto,ptt);
        ptd = [x y];
        %ii:
        [x, y] = lineIntr(pta,ptb,ptc,ptd);
        pti = [x y];
        ang = vectAng(ptb-pti,ptd-pti);
        if ang > 0 %Explicit
            %outer corner (b1):
            mdl_type(ii) = 5;
            r_b = sqrt(ptb*ptb');
            r_d = sqrt(ptd*ptd');
            if r_b > ds(ii)+r_add
                %detect two corners in the range
                ptb = ds(ii)*[cos(theta(ii)+a(ii)/2) sin(theta(ii)+a(ii)/2)];
                [x, y] = lineIntr(pta,ptb,ptc,ptd);
                pti = [x y];
            end
            if r_d > ds(ii)+r_add
                %detect two corners in the range
                ptd = ds(ii)*[cos(theta(ii)-a(ii)/2) sin(theta(ii)-a(ii)/2)];
                [x, y] = lineIntr(pta,ptb,ptc,ptd);
                pti = [x y];
            end
            mdl_pt(ii,:) = [ ...
                ptb(1) pti(1) ptd(1), ...
                ptb(2) pti(2) ptd(2)];
            mdl_pt(ij,:) = [ ...
                pta(1) ptb(1) NaN, ...
                pta(2) ptb(2) NaN];
            mdl_pt(ik,:) = [ ...
                ptc(1) ptd(1) NaN, ...
                ptc(2) ptd(2) NaN];
            mdl_done([ij ik]) = true;
        else %ang < 0 %Implicit
            %outer corner (b2):
            mdl_type(ii) = 6;
            ang_ia = vectAng(pti,pta);
            ang_ib = vectAng(pti,ptb);
            ang_ic = vectAng(pti,ptc);
            ang_id = vectAng(pti,ptd);
            if ang_ia*ang_ib < 0
                r_b = sqrt(ptb*ptb');
                if r_b < ds(ij)+r_add
                    %pto = [0 0];
                    ptt = ds(ii)*[ ...
                        cos(theta(ii)+a(ii)/2) sin(theta(ii)+a(ii)/2)];
                    [x, y] = lineIntr(ptc,ptd,pto,ptt);
                    mdl_pt(ii,:) = [ ...
                        ptd(1) x NaN, ...
                        ptd(2) y NaN];
                    mdl_pt(ij,:) = [ ...
                        x pti(1) pta(1), ...
                        y pti(2) pta(2)];
                    mdl_pt(ik,:) = [ ...
                        ptc(1) ptd(1) NaN, ...
                        ptc(2) ptd(2) NaN];
                    mdl_pt(il,:) = [ ...
                        pte(1) pta(1) NaN, ...
                        pte(2) pta(2) NaN];
                    mdl_done([ij ik il]) = true;
                else %r_b > ds(ij)+r_add
                    %detect two corners in the range
                    %ii:
                    D1 = ds(ii);
                    D2 = ds(ij);
                    mdl_pt(ii,:) = [ ...
                        D1*cos(theta(ii)-a(ii)/2) D2*cos(theta(ii)+a(ii)/2) NaN, ...
                        D1*sin(theta(ii)-a(ii)/2) D2*sin(theta(ii)+a(ii)/2) NaN];
                    %ij:
                    D1 = ds(ij);
                    D2 = D1;
                    mdl_pt(ij,:) = [ ...
                        D1*cos(theta(ij)-a(ij)/2) D2*cos(theta(ij)+a(ij)/2) NaN, ...
                        D1*sin(theta(ij)-a(ij)/2) D2*sin(theta(ij)+a(ij)/2) NaN];
                    %ik:
                    D1 = ds(ik);
                    D2 = ds(ii);
                    mdl_pt(ik,:) = [ ...
                        D1*cos(theta(ik)-a(ik)/2) D2*cos(theta(ik)+a(ik)/2) NaN, ...
                        D1*sin(theta(ik)-a(ik)/2) D2*sin(theta(ik)+a(ik)/2) NaN];
                    mdl_done([ij ik]) = true;
                end
            elseif ang_ic*ang_id < 0
                r_d = sqrt(ptd*ptd');
                if r_d < ds(ik)+r_add
                    %pto = [0 0];
                    ptt = ds(ii)*[ ...
                        cos(theta(ii)-a(ii)/2) sin(theta(ii)-a(ii)/2)];
                    [x, y] = lineIntr(pta,ptb,pto,ptt);
                    mdl_pt(ii,:) = [ ...
                        ptb(1) x NaN, ...
                        ptb(2) y NaN];
                    mdl_pt(ik,:) = [ ...
                        x pti(1) ptc(1), ...
                        y pti(2) ptc(2)];
                    mdl_pt(ij,:) = [ ...
                        pta(1) ptb(1) NaN, ...
                        pta(2) ptb(2) NaN];
                    mdl_pt(im,:) = [ ...
                        ptf(1) ptc(1) NaN, ...
                        ptf(2) ptc(2) NaN];
                    mdl_done([ij ik im]) = true;
                else %r_d > ds(ik)+r_add
                    %detect two corners in the range
                    %ii:
                    D1 = ds(ii);
                    D2 = ds(ik);
                    mdl_pt(ii,:) = [ ...
                        D1*cos(theta(ii)+a(ii)/2) D2*cos(theta(ii)-a(ii)/2) NaN, ...
                        D1*sin(theta(ii)+a(ii)/2) D2*sin(theta(ii)-a(ii)/2) NaN];
                    %ik:
                    D1 = ds(ik);
                    D2 = D1;
                    mdl_pt(ik,:) = [ ...
                        D1*cos(theta(ik)+a(ik)/2) D2*cos(theta(ik)-a(ik)/2) NaN, ...
                        D1*sin(theta(ik)+a(ik)/2) D2*sin(theta(ik)-a(ik)/2) NaN];
                    %ij:
                    D1 = ds(ij);
                    D2 = ds(ii);
                    mdl_pt(ij,:) = [ ...
                        D1*cos(theta(ij)+a(ij)/2) D2*cos(theta(ij)-a(ij)/2) NaN, ...
                        D1*sin(theta(ij)+a(ij)/2) D2*sin(theta(ij)-a(ij)/2) NaN];
                    mdl_done([ij ik]) = true;
                end
            else
                %undefined situation:
                mdl_type(ii) = 8;
                D1 = ds(ii)/cos(a(ii)/2);
                D2 = D1;
                mdl_pt(ii,:) = [ ...
                    D1*cos(theta(ii)+a(ii)/2) D2*cos(theta(ii)-a(ii)/2) NaN, ...
                    D1*sin(theta(ii)+a(ii)/2) D2*sin(theta(ii)-a(ii)/2) NaN];
            end
        end
    elseif dsR(1)+dsR(2) < 0
        %inner corner:
        mdl_type(ii) = 7;
        D1 = ds(ij);
        D2 = ds(ik);
        D3 = ds(ii);
        if dsR(1)==-1 && dsR(2)==-1
            mdl_pt(ii,:) = [ ...
                D1*cos(theta(ii)+a(ii)/2) D2*cos(theta(ii)-a(ii)/2) NaN, ...
                D1*sin(theta(ii)+a(ii)/2) D2*sin(theta(ii)-a(ii)/2) NaN];
        else
            mdl_pt(ii,:) = [ ...
                D1*cos(theta(ii)+a(ii)/2) D3*cos(theta(ii)) D2*cos(theta(ii)-a(ii)/2), ...
                D1*sin(theta(ii)+a(ii)/2) D3*sin(theta(ii)) D2*sin(theta(ii)-a(ii)/2)];
        end
    else
        %undefined situation:
        mdl_type(ii) = 8;
        D1 = ds(ii)/cos(a(ii)/2);
        D2 = D1;
        mdl_pt(ii,:) = [ ...
            D1*cos(theta(ii)+a(ii)/2) D2*cos(theta(ii)-a(ii)/2) NaN, ...
            D1*sin(theta(ii)+a(ii)/2) D2*sin(theta(ii)-a(ii)/2) NaN];
    end
    mdl_done(ii) = true;
%     %DEBUG
%     plot(mdl_pt(ii,1:3),mdl_pt(ii,4:6),'k')
%     plot(mdl_pt(ij,1:3),mdl_pt(ij,4:6),'k')
%     plot(mdl_pt(ik,1:3),mdl_pt(ik,4:6),'k')
%     plot(mdl_pt(il,1:3),mdl_pt(il,4:6),'k')
%     plot(mdl_pt(im,1:3),mdl_pt(im,4:6),'k')
%     % %
end

    function dsR = CompdsR
        %Compute dsR
        dsR = zeros(1,4);
        %i->j:
        if ds(ii) > ds(ij)
            if ds(ii) < ds(ij)/cos(a(ij))*(1+offset)
                dsR(1) = 1;
            elseif (ds(ii)-ds(ij)) < d_th
                dsR(1) = 2;
            else
                dsR(1) = 3;
            end
        else
            if ds(ij) < ds(ii)/cos(a(ii))*(1+offset)
                dsR(1) = -1;
            elseif (ds(ij)-ds(ii)) < d_th
                dsR(1) = -2;
            else
                dsR(1) = -3;
            end
        end
        %i->k:
        if ds(ii) > ds(ik)
            if ds(ii) < ds(ik)/cos(a(ik))*(1+offset)
                dsR(2) = 1;
            elseif (ds(ii)-ds(ik)) < d_th
                dsR(2) = 2;
            else
                dsR(2) = 3;
            end
        else
            if ds(ik) < ds(ii)/cos(a(ii))*(1+offset)
                dsR(2) = -1;
            elseif (ds(ik)-ds(ii)) < d_th
                dsR(2) = -2;
            else
                dsR(2) = -3;
            end
        end
        %j->l:
        if ds(ij) > ds(il)
            if ds(ij) < ds(il)/cos(a(il))*(1+offset)
                dsR(3) = 1;
            elseif (ds(ij)-ds(il)) < d_th
                dsR(3) = 2;
            else
                dsR(3) = 3;
            end
        else
            if ds(il) < ds(ij)/cos(a(ij))*(1+offset)
                dsR(3) = -1;
            elseif (ds(il)-ds(ij)) < d_th
                dsR(3) = -2;
            else
                dsR(3) = -3;
            end
        end
        %k->m:
        if ds(ik) > ds(im)
            if ds(ik) < ds(im)/cos(a(im))*(1+offset)
                dsR(4) = 1;
            elseif (ds(ik)-ds(im)) < d_th
                dsR(4) = 2;
            else
                dsR(4) = 3;
            end
        else
            if ds(im) < ds(ik)/cos(a(ik))*(1+offset)
                dsR(4) = -1;
            elseif (ds(im)-ds(ik)) < d_th
                dsR(4) = -2;
            else
                dsR(4) = -3;
            end
        end
    end

    function idx = nextIdx(ii,N,m)
        idx = 1+mod(ii-1+m,N);
    end

    function [x, y] = lineIntr(pa,pb,pc,pd)
        %A*x+B*y==E && C*x+D*y==F
        A = pa(2)-pb(2);
        C = pc(2)-pd(2);
        B = -(pa(1)-pb(1));
        D = -(pc(1)-pd(1));
        E = (pa(2)-pb(2))*pa(1)-(pa(1)-pb(1))*pa(2);
        F = (pc(2)-pd(2))*pc(1)-(pc(1)-pd(1))*pc(2);
        x = det([E B;F D])/det([A B;C D]);
        y = det([A E;C F])/det([A B;C D]);
    end

    function ang = vectAng(A,B)
        %angle from A to B (degrees)
        angA = atan2(A(2),A(1));
        angB = atan2(B(2),B(1));
        ang = (angB-angA)/pi*180;
        if ang < -180
            ang = ang+360;
        end
        if ang > +180
            ang = ang-360;
        end
    end

end
