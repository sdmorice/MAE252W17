% distsensorrobot.m itself is a demo of using distsensormodel.m which performs the multiple ultrasonic sensor based environment modeling algorithm.
% sonosensure.m simulates measurement results of ultrasonic sensors.
distsensorrobot
